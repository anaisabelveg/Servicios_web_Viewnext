package com.viewnext.business;

import com.viewnext.models.Pedido;

public interface IPedidoService {
	
	Pedido crearPedido(Long id, int cantidad);

}
