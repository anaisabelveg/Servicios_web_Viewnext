package com.viewnext.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
public class PedidoServiceRestTemplate implements IPedidoService{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
		Producto producto = restTemplate.getForObject("http://localhost:8001/buscar/{codigo}", Producto.class, id);
		
		// Crear el pedido y retornarlo
		return new Pedido(producto, cantidad);
	}

}
