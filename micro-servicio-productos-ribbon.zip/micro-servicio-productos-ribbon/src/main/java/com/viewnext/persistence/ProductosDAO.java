package com.viewnext.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.viewnext.models.Producto;

@RepositoryRestResource(collectionResourceRel = "PRODUCTOS")
public interface ProductosDAO extends JpaRepository<Producto, Long>{

}
