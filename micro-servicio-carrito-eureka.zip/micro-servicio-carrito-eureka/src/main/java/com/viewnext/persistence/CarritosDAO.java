package com.viewnext.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.viewnext.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "CARRITOS")
public interface CarritosDAO extends MongoRepository<Carrito, String>{
	
	public Carrito findByUsuario(String usuario);

}
