package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.business.ICarritoBS;
import com.viewnext.models.Carrito;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoBS carritoBS;
	
	// http://localhost:8003/crear/Jose
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return carritoBS.crear(usuario);
	}
	
	// http://localhost:8003/agregarPedido/2/cantidad/100/usuario/Jose
	@PutMapping("/agregarPedido/{id}/cantidad/{cantidad}/usuario/{usuario}")
    public Carrito agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, @PathVariable String usuario) {
		return carritoBS.agregarPedido(id, cantidad, usuario);
	}
     
	// http://localhost:8003/consultar/Jose
	@GetMapping("/consultar/{usuario}")
    public Carrito consultar(@PathVariable String usuario) {
    	return carritoBS.consultar(usuario);
    }
     
	// http://localhost:8003/eliminarPedido/2/usuario/Jose
	@DeleteMapping("/eliminarPedido/{id}/usuario/{usuario}")
    public Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
    	return carritoBS.eliminarPedido(id, usuario);
    }
     

}
