package com.viewnext.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.viewnext.clients.ProductosClientFeign;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
@Primary
public class PedidoServiceFeign implements IPedidoService{
	
	@Autowired
	private ProductosClientFeign clienteFeign;

	@Override
	// En el caso de recibir una excepcion llamamos al metodo alternativo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}
	
	// El metodo alternativo debe tener la misma declaracion que el original,
	// tambien recibiremos la excepcion
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage());
		System.out.println(ex.getClass() + "**********************");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	}

}
