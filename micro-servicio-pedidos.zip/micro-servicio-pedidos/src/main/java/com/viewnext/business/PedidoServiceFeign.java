package com.viewnext.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.viewnext.clients.ProductosClientFeign;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
@Primary
public class PedidoServiceFeign implements IPedidoService{
	
	@Autowired
	private ProductosClientFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}

}
