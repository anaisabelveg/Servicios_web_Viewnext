package com.viewnext.business;

import java.util.List;

import com.viewnext.models.Carrito;
import com.viewnext.models.Producto;

public interface ItfzProductosBS {
	
	List<Producto> obtenerTodos();
	
	Producto consultarProducto(Long id);
	
	Carrito consultar(String usuario);
	
	Carrito crear(String usuario);
	
	Carrito agregar(Long id, int cantidad, String usuario);
	
	Carrito eliminar(Long id, String usuario);

}
