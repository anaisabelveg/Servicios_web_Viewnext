package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.viewnext.business.ProductosBS;

@SpringBootApplication
public class AppFrontWebApplication implements CommandLineRunner{
	
	
	
	@Autowired
	private ProductosBS productosBS;

	public static void main(String[] args) {
		SpringApplication.run(AppFrontWebApplication.class, args);
	}

	
	@Override
	public void run(String... args) throws Exception {
		// Mostrar todos los productos
		productosBS.obtenerTodos()
			.stream()
			.forEach(System.out::println);
		
		// Buscar un producto
		System.out.println("Encontrado: " + productosBS.consultarProducto(4L));
		
		// Crear el carrito de Maria
		System.out.println("Crear carrito " + productosBS.crear("Maria") );
		
		// Agregar un pedido al carrito
		System.out.println("Agregar el pedido " + productosBS.agregar(4L, 10, "Maria"));
		
		// Consultar el carrito
		System.out.println("Consultar carrito " + productosBS.consultar("Maria"));
		
		// Eliminando un pedido del carrito
		System.out.println("Eliminar el pedido " + productosBS.eliminar(4L, "Maria"));
		
		
	}

}
