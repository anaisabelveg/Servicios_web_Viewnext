package com.grupoatrium.servicios;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

@Path("/centigrados")
public class FarenheitGrados {
	
	// http://localhost:8080/Rest_Grados/servlet/centigrados
	@GET
	@Produces("application/json")
	public Response convertirCentigrados(){
		double farenheit = 98.24;
		double centigrados = (farenheit - 32) * 5 / 9;
		
		// Construir un objeto JSON
		JSONObject json = new JSONObject();
		json.put("farenheit", farenheit);
		json.put("celsius", centigrados);
		
		return Response.status(200).entity(json.toString()).build();
	}
	
	// http://localhost:8080/Rest_Grados/servlet/centigrados/92.37
	@Path("{f}")
	@GET
	@Produces("application/json")
	public Response convertirCentigrados(@PathParam("f") double farenheit ){

		double centigrados = (farenheit - 32) * 5 / 9;
		
		// Construir un objeto JSON
		JSONObject json = new JSONObject();
		json.put("farenheit", farenheit);
		json.put("celsius", centigrados);
		
		return Response.status(200).entity(json.toString()).build();
	}

}
