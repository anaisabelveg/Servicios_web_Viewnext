package com.grupoatrium.servicios;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/farenheit")
public class GradosFarenheit {
	
	// http://localhost:8080/Rest_Grados/servlet/farenheit
	@GET
	@Produces("application/xml")
	public String convertirFarenheit(){
		double celsius = 36.8;
		double farenheit = (celsius * 9 / 5) + 32;
		
		String resultado = "<conversor>" +
		           "<celsius>" + celsius  + "</celsius>" +
		           "<farenheit>" + farenheit + "</farenheit>" +     
				"</conversor>";
		return resultado;
	}
	
	// http://localhost:8080/Rest_Grados/servlet/farenheit/35
	@Path("{c}")
	@GET
	@Produces("application/xml")
	public String convertirFarenheit(@PathParam("c") double celsius){
		double farenheit = (celsius * 9 / 5) + 32;
		
		String resultado = "<conversor>" +
		           "<celsius>" + celsius  + "</celsius>" +
		           "<farenheit>" + farenheit + "</farenheit>" +     
				"</conversor>";
		
		return resultado;
	}

}
