package com.grupoatrium.cliente;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class AppMain {

	private void procesarXML() {
		Client cliente = Client.create();
		String url = "http://localhost:8080/Rest_Grados/servlet/farenheit/35/";
		WebResource peticion = cliente.resource(url);

		ClientResponse respuesta = peticion.accept("application/xml").get(
				ClientResponse.class);
		if (respuesta.getStatus() == 200) {
			System.out.println(respuesta.getEntity(String.class));
		}
	}
	
	private void procesarJSON(){
		Client cliente = Client.create();
		String url = "http://localhost:8080/Rest_Grados/servlet/centigrados/92.37/";
		WebResource peticion = cliente.resource(url);
		
		ClientResponse respuesta = peticion.accept("application/json").get(
				ClientResponse.class);
		if (respuesta.getStatus() == 200) {
			System.out.println(respuesta.getEntity(String.class));
		}
		
	}

	public static void main(String[] args) {
		AppMain main = new AppMain();
		main.procesarXML();
		main.procesarJSON();
	}

}
